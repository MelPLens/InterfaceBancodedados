
package Objetos;


public class Clienteclasse {
    private String nome;
    private String CPF;
    private String endereco;
    private String cidade;
    private String estado;

    //Metodo Construtor
    public Clienteclasse(String nome,String CPF,String endereco,String cidade,String estado){
        this.CPF=CPF; //iniciando atributos
        this.cidade=cidade;
        this.endereco=endereco;
        this.estado=estado;
        this.nome=nome;
    }
  
    
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

   
    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    
    
    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

   
    
    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

   
    
    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    //Criar um método “LimpaCliente” que terá como objetivo
    //limpar todos os atributos, ou seja, inserir uma string vazia.

    public void LimpaCliente(){
                 nome = " " ;  // o simbolo de mais é para concatenar '' não utilizado aqui''
                 CPF = " ";
                 endereco= " " ;    
                 cidade=" " ;
                 estado=" ";
                 
    }
}

          


