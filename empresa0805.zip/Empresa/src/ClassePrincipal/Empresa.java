//crud
//c - create/insert
// r - read
// u - update
// d - delete

package ClassePrincipal;


public class Empresa {

   
    public static void main(String[] args) {
     
    }
    
}
