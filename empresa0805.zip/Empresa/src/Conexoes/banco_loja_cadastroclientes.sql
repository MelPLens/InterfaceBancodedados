CREATE DATABASE  IF NOT EXISTS banco_loja
USE banco_loja;


DROP TABLE IF EXISTS cadastroclientes;

CREATE TABLE cadastroclientes (
  id int(11) NOT NULL AUTO_INCREMENT,
  nome varchar(45) NOT NULL,
  cpf varchar(45) NOT NULL,
  sexo varchar(45) NOT NULL,
  endereco varchar(100) NOT NULL,
  cidade varchar(45) NOT NULL,
  estado varchar(45) NOT NULL,
  PRIMARY KEY (id)
) 

