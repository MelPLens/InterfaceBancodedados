
package Objetos;

public class Produtoclasse {
   // Deverá ter os atributos: produto (para armazenar o nome),
   //descrição e fornecedor (serão do tipo string)
   //Deverá ter os atributos: custo, venda e icms (serão do tipo float)
   //Deverá ter o atributo tamanho que será do tipo int.
    private String produto;
    private String descricao;
    private String fornecedor;
    private float custo;
    private float venda;
    private float icms;
    private int tamanho;
    
    public Produtoclasse(){
        
    }
   
            
    public Produtoclasse(String produto,String descricao,String fornecedor
            ,float custo,float venda,float icms,int tamanho){
        this.produto=produto; //iniciando atributos
        this.descricao=descricao;
        this.fornecedor=fornecedor;
        this.custo=custo;
        this.venda=venda;
        this.icms=icms;
        this.tamanho=tamanho;
    }

    /**
     * @return the produto
     */
    public String getProduto() {
        return produto;
    }

    /**
     * @param produto the produto to set
     */
    public void setProduto(String produto) {
        this.produto = produto;
    }

    /**
     * @return the descricao
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * @param descricao the descricao to set
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    /**
     * @return the fornecedor
     */
    public String getFornecedor() {
        return fornecedor;
    }

    /**
     * @param fornecedor the fornecedor to set
     */
    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }

    /**
     * @return the custo
     */
    public float getCusto() {
        return custo;
    }

    /**
     * @param custo the custo to set
     */
    public void setCusto(float custo) {
        this.custo = custo;
    }

    /**
     * @return the venda
     */
    public float getVenda() {
        return venda;
    }

    /**
     * @param venda the venda to set
     */
    public void setVenda(float venda) {
        this.venda = venda;
    }

    /**
     * @return the icms
     */
    public float getIcms() {
        return icms;
    }

    /**
     * @param icms the icms to set
     */
    public void setIcms(float icms) {
        this.icms = icms;
    }

    /**
     * @return the tamanho
     */
    public int getTamanho() {
        return tamanho;
    }

    /**
     * @param tamanho the tamanho to set
     */
    public void setTamanho(int tamanho) {
        this.tamanho = tamanho;
    }
    
    
    
}
