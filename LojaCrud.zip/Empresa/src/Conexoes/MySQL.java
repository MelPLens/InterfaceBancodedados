
package Conexoes;


public class MySQL {
    
}
