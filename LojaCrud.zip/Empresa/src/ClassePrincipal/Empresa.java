
package ClassePrincipal;


public class Empresa {

   
    public static void main(String[] args) {
     
    }
    
}
